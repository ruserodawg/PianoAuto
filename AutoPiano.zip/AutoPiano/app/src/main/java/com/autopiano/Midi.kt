package com.autopiano

import java.util.TreeMap

data class Note(val startMs: Double, val endMs: Double, val note: Int, val vel: Int)
class Song(val notes: List<Note>) { val durationMs = notes.maxOfOrNull { it.endMs } ?: 0.0 }

object MidiParser {
    private class R(val d: ByteArray, var p: Int = 0) {
        fun u8() = d[p++].toInt() and 0xFF
        fun u16() = (u8() shl 8) or u8()
        fun u32() = (u16() shl 16) or u16()
        fun skip(n: Int) { p += n }
        fun vlq(): Int { var v = 0; do { val b = u8(); v = (v shl 7) or (b and 0x7F) } while (b >= 0x80); return v }
    }
    private class Raw(val s: Long, val e: Long, val n: Int, val v: Int)

    fun parse(d: ByteArray): Song {
        require(d.size > 14 && String(d, 0, 4) == "MThd") { "Not a MIDI file" }
        val r = R(d, 4)
        val hl = r.u32(); r.u16(); val tracks = r.u16(); val div = r.u16()
        require(div and 0x8000 == 0) { "SMPTE timing not supported" }
        r.p = 8 + hl
        val tempos = TreeMap<Long, Int>().apply { put(0L, 500000) }
        val raws = ArrayList<Raw>()
        repeat(tracks) {
            if (r.p + 8 > d.size) return@repeat
            r.skip(4)
            val len = r.u32(); val end = minOf(r.p + len, d.size)
            var tick = 0L; var status = 0
            val open = HashMap<Int, ArrayDeque<Pair<Long, Int>>>()
            while (r.p < end) {
                tick += r.vlq()
                var b = r.u8()
                if (b < 0x80) { r.p--; b = status } else if (b < 0xF0) status = b
                when {
                    b == 0xFF -> {
                        val t = r.u8(); val l = r.vlq()
                        if (t == 0x51 && l == 3) tempos[tick] = (r.u8() shl 16) or (r.u8() shl 8) or r.u8() else r.skip(l)
                    }
                    b >= 0xF0 -> r.skip(r.vlq())
                    else -> {
                        val ch = b and 15; val k = b and 0xF0
                        when (k) {
                            0x80, 0x90 -> {
                                val n = r.u8(); val v = r.u8(); val id = ch * 128 + n
                                if (k == 0x90 && v > 0) open.getOrPut(id) { ArrayDeque() }.addLast(tick to v)
                                else open[id]?.removeFirstOrNull()?.let { if (ch != 9) raws += Raw(it.first, tick, n, it.second) }
                            }
                            0xC0, 0xD0 -> r.skip(1)
                            else -> r.skip(2)
                        }
                    }
                }
            }
            open.forEach { (id, q) -> if (id / 128 != 9) q.forEach { raws += Raw(it.first, tick, id % 128, it.second) } }
            r.p = end
        }
        val ticks = tempos.keys.toLongArray(); val us = tempos.values.toIntArray()
        val base = DoubleArray(ticks.size)
        for (i in 1 until ticks.size) base[i] = base[i - 1] + (ticks[i] - ticks[i - 1]) * us[i - 1] / 1000.0 / div
        fun ms(t: Long): Double {
            val i = ticks.binarySearch(t).let { if (it >= 0) it else -it - 2 }
            return base[i] + (t - ticks[i]) * us[i] / 1000.0 / div
        }
        return Song(raws.map { Note(ms(it.s), maxOf(ms(it.e), ms(it.s) + 20), it.n, it.v) }.sortedBy { it.startMs })
    }
}
