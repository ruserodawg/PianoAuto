package com.autopiano

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.*

class AutoPianoService : AccessibilityService() {
    companion object { @Volatile var instance: AutoPianoService? = null }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var player: Player
    private lateinit var overlay: Overlay

    override fun onServiceConnected() {
        instance = this
        player = Player(this, scope)
        overlay = Overlay(this, player, scope)
    }

    fun loadMidi(bytes: ByteArray, onError: (String) -> Unit) {
        scope.launch {
            try {
                val s = withContext(Dispatchers.Default) { MidiParser.parse(bytes) }
                player.load(s); overlay.refresh()
            } catch (e: Exception) { onError(e.message ?: "Could not read MIDI") }
        }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { if (::player.isInitialized) player.pause() }
    override fun onDestroy() {
        instance = null; scope.cancel()
        if (::overlay.isInitialized) overlay.remove()
        super.onDestroy()
    }
}
