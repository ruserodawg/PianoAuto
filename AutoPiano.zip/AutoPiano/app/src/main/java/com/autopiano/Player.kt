package com.autopiano

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.graphics.Path
import android.graphics.PointF
import android.os.SystemClock
import kotlinx.coroutines.*
import kotlin.coroutines.resume

/** Song time (ms at 1.0x). Pause/seek/tempo only change this clock. */
class SongClock {
    private var base = 0.0
    private var anchor = 0L
    @Volatile var speed = 1.0; private set
    @Volatile var playing = false; private set
    @Synchronized fun position(): Double = if (playing) base + (SystemClock.elapsedRealtime() - anchor) * speed else base
    @Synchronized fun play() { if (!playing) { anchor = SystemClock.elapsedRealtime(); playing = true } }
    @Synchronized fun pause() { base = position(); playing = false }
    @Synchronized fun seek(ms: Double) { base = ms; anchor = SystemClock.elapsedRealtime() }
    @Synchronized fun setSpeed(s: Double) { base = position(); anchor = SystemClock.elapsedRealtime(); speed = s }
}

/**
 * Plays in short "frames" (F ms). Every frame is one gesture containing:
 *  - a continuation of each held key (willContinue = true until its note-off arrives)
 *  - new strokes for notes starting inside the frame
 */
class Player(private val svc: AccessibilityService, scope: CoroutineScope) {
    val clock = SongClock()
    @Volatile var song: Song? = null
    @Volatile var layout: KeyLayout? = null
    @Volatile var onFinished: () -> Unit = {}
    var latencyMs = 25          // compensates gesture dispatch delay; tune per device
    private val F = 50L         // frame length
    private val MIN_TAP = 30L   // shortest press
    private val GAP = 8L        // release gap before re-pressing the same key

    private var cursor = 0
    @Volatile private var seekTo = -1.0
    private class Held(val stroke: StrokeDescription, val pt: PointF, val endMs: Double)
    private val held = HashMap<Int, Held>()

    fun load(s: Song) { clock.pause(); song = s; seek(0.0) }
    fun play() { val s = song ?: return; if (layout == null) return; if (clock.position() >= s.durationMs) seek(0.0); clock.play() }
    fun pause() = clock.pause()
    fun seek(ms: Double) { clock.seek(ms); seekTo = ms }
    fun setTempo(x: Double) = clock.setSpeed(x)

    init { scope.launch { loop() } }

    private suspend fun loop() {
        while (true) {
            val s = song; val lay = layout
            if (seekTo >= 0) {
                val t = seekTo; seekTo = -1.0
                releaseAll()
                cursor = s?.notes?.let { n -> n.indexOfFirst { it.startMs >= t }.let { i -> if (i < 0) n.size else i } } ?: 0
            }
            if (s == null || lay == null || !clock.playing) { releaseAll(); delay(30); continue }
            step(s, lay)
        }
    }

    private fun path(p: PointF) = Path().apply { moveTo(p.x, p.y) }

    private suspend fun step(s: Song, lay: KeyLayout) {
        val sp = clock.speed
        val pos = clock.position() + latencyMs * sp
        val end = pos + F * sp
        fun off(ms: Double) = ((ms - pos) / sp).toLong()

        val fresh = LinkedHashMap<Int, Note>()
        while (cursor < s.notes.size && s.notes[cursor].startMs < end) {
            val n = s.notes[cursor++]; fresh.putIfAbsent(lay.fold(n.note), n)
        }
        // touch limit: drop quietest new notes first
        val cap = (GestureDescription.getMaxStrokeCount() - held.size).coerceAtLeast(0)
        val starts = fresh.entries.sortedByDescending { it.value.vel }.take(cap).associate { it.key to it.value }

        if (held.isEmpty() && starts.isEmpty()) {
            if (cursor >= s.notes.size) { clock.pause(); clock.seek(s.durationMs); onFinished(); return }
            delay(((s.notes[cursor].startMs - pos) / sp - F / 2).toLong().coerceIn(1L, 50L)); return
        }

        val strokes = ArrayList<StrokeDescription>()
        val next = HashMap<Int, Held>()
        for ((k, h) in held) {
            val re = starts[k]
            val done = re != null || h.endMs < end
            val cut = when { re != null -> off(re.startMs) - GAP; h.endMs < end -> off(h.endMs); else -> F }.coerceIn(1L, F)
            val st = h.stroke.continueStroke(path(h.pt), 0L, cut, !done)
            strokes += st
            if (!done) next[k] = Held(st, h.pt, h.endMs)
        }
        for ((k, n) in starts) {
            val p = lay.point(k)
            val so = off(n.startMs).coerceIn(if (held.containsKey(k)) GAP + 1 else 0L, F - 1)
            val eo = off(n.endMs)
            val fits = eo <= F
            val st = StrokeDescription(path(p), so, if (fits) maxOf(MIN_TAP, eo - so) else F - so, !fits)
            strokes += st
            if (!fits) next[k] = Held(st, p, n.endMs)
        }
        val ok = dispatch(GestureDescription.Builder().apply { strokes.forEach { addStroke(it) } }.build())
        held.clear(); if (ok) held.putAll(next)
    }

    private suspend fun releaseAll() {
        if (held.isEmpty()) return
        val b = GestureDescription.Builder()
        held.values.forEach { b.addStroke(it.stroke.continueStroke(path(it.pt), 0L, 1L, false)) }
        dispatch(b.build()); held.clear()
    }

    private suspend fun dispatch(g: GestureDescription): Boolean = suspendCancellableCoroutine { c ->
        val sent = svc.dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { if (c.isActive) c.resume(true) }
            override fun onCancelled(d: GestureDescription?) { if (c.isActive) c.resume(false) }
        }, null)
        if (!sent && c.isActive) c.resume(false)
    }
}
