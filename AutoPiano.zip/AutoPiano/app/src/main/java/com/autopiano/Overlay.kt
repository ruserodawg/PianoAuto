package com.autopiano

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PointF
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.*
import kotlinx.coroutines.*

/** Floating control panel + 3-tap calibration. Uses an accessibility overlay (no extra permission). */
class Overlay(private val svc: AccessibilityService, private val p: Player, scope: CoroutineScope) {
    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = svc.getSharedPreferences("ap", Context.MODE_PRIVATE)
    private val dp = svc.resources.displayMetrics.density
    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private val pp = params(-2, -2).apply { x = 40; y = 40 }
    private var dragging = false
    private var dx = 0f
    private var dy = 0f

    private val time = TextView(svc).apply { setTextColor(Color.WHITE); textSize = 14f; setPadding(8, 8, 16, 8) }
    private val play = Button(svc).apply { setAllCaps(false); minWidth = 0; setOnClickListener { if (p.clock.playing) p.pause() else p.play(); refresh() } }
    private val tempoLabel = TextView(svc).apply { setTextColor(Color.WHITE); text = "Tempo 100%" }
    private val seek = SeekBar(svc).apply {
        max = 1000
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, v: Int, user: Boolean) { if (user) p.seek(v / 1000.0 * (p.song?.durationMs ?: 0.0)) }
            override fun onStartTrackingTouch(s: SeekBar) { dragging = true }
            override fun onStopTrackingTouch(s: SeekBar) { dragging = false }
        })
    }
    private val tempo = SeekBar(svc).apply {
        max = 175; progress = 75   // 25%..200%, default 100%
        setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, v: Int, user: Boolean) { p.setTempo((25 + v) / 100.0); tempoLabel.text = "Tempo ${25 + v}%" }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
    }
    private val panel = LinearLayout(svc).apply {
        orientation = LinearLayout.VERTICAL; setBackgroundColor(0xCC202020.toInt()); setPadding(16, 16, 16, 16)
        addView(LinearLayout(svc).apply {
            addView(time); addView(play)
            addView(Button(svc).apply { text = "Calibrate"; setAllCaps(false); minWidth = 0; setOnClickListener { calibrate() } })
        })
        addView(seek, LinearLayout.LayoutParams((260 * dp).toInt(), -2))
        addView(tempoLabel)
        addView(tempo, LinearLayout.LayoutParams((260 * dp).toInt(), -2))
    }

    init {
        if (prefs.contains("xl")) p.layout = KeyLayout(36, 96, prefs.getFloat("xl", 0f), prefs.getFloat("xh", 0f), prefs.getFloat("yw", 0f), prefs.getFloat("yb", 0f))
        time.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = pp.x - e.rawX; dy = pp.y - e.rawY }
                MotionEvent.ACTION_MOVE -> { pp.x = (e.rawX + dx).toInt(); pp.y = (e.rawY + dy).toInt(); wm.updateViewLayout(panel, pp) }
            }
            true
        }
        wm.addView(panel, pp)
        p.onFinished = { refresh() }
        scope.launch { while (true) { refresh(); delay(200) } }
    }

    fun remove() { runCatching { wm.removeView(panel) } }

    fun refresh() {
        val pos = p.clock.position(); val dur = p.song?.durationMs ?: 0.0
        time.text = "⠿ ${fmt(pos)} / ${fmt(dur)}"
        play.text = if (p.clock.playing) "⏸" else "▶"
        if (!dragging && dur > 0) seek.progress = (pos / dur * 1000).toInt().coerceIn(0, 1000)
    }
    private fun fmt(ms: Double) = (ms / 1000).toInt().let { "%d:%02d".format(it / 60, it % 60) }

    private fun calibrate() {
        val steps = listOf("Tap the LEFT white key (C2)", "Tap the RIGHT white key (C7)", "Tap any BLACK key (e.g. C#2)")
        val pts = ArrayList<PointF>()
        val v = TextView(svc).apply {
            text = steps[0]; textSize = 22f; setTextColor(Color.WHITE); setBackgroundColor(0x55000000)
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; setPadding(0, 120, 0, 0)
        }
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                pts += PointF(e.rawX, e.rawY)
                if (pts.size < 3) v.text = steps[pts.size] else {
                    wm.removeView(v)
                    val yw = (pts[0].y + pts[1].y) / 2
                    p.layout = KeyLayout(36, 96, pts[0].x, pts[1].x, yw, pts[2].y)
                    prefs.edit().putFloat("xl", pts[0].x).putFloat("xh", pts[1].x).putFloat("yw", yw).putFloat("yb", pts[2].y).apply()
                }
            }
            true
        }
        wm.addView(v, params(-1, -1))
    }
}
