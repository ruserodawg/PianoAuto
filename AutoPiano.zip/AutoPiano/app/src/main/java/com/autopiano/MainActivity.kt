package com.autopiano

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val info = TextView(this).apply {
            textSize = 16f
            text = "1) Enable AutoPiano in Accessibility\n2) Pick a MIDI file\n3) Open your piano app, tap Calibrate on the floating panel, then ▶"
        }
        val a11y = Button(this).apply { text = "Open Accessibility settings"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } }
        val pick = Button(this).apply {
            text = "Pick MIDI file"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }, 1)
            }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48)
            addView(info); addView(a11y); addView(pick)
        })
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        val svc = AutoPianoService.instance
        if (svc == null) { Toast.makeText(this, "Enable the accessibility service first", Toast.LENGTH_LONG).show(); return }
        val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
        svc.loadMidi(bytes) { Toast.makeText(this, it, Toast.LENGTH_LONG).show() }
        Toast.makeText(this, "MIDI loaded. Switch to your piano app.", Toast.LENGTH_SHORT).show()
    }
}
