package com.autopiano

import android.graphics.PointF

/** low/high = white-key MIDI notes (36 = C2, 96 = C7). x = white key centers, y = where to tap. */
class KeyLayout(val low: Int, val high: Int, val xLow: Float, val xHigh: Float, val yWhite: Float, val yBlack: Float) {
    private val idx = intArrayOf(0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6)
    private fun wi(n: Int) = (n / 12) * 7 + idx[n % 12]
    private val w = (xHigh - xLow) / (wi(high) - wi(low))
    private fun isBlack(n: Int) = n % 12 in intArrayOf(1, 3, 6, 8, 10)

    fun fold(note: Int): Int { var n = note; while (n < low) n += 12; while (n > high) n -= 12; return n }

    fun point(n: Int): PointF {
        val a = wi(n) - wi(low)
        return if (isBlack(n)) PointF(xLow + (a + 0.5f) * w, yBlack) else PointF(xLow + a * w, yWhite)
    }
}
